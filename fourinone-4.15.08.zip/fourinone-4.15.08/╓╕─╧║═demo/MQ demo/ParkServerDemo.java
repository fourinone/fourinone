import com.fourinone.BeanContext;

public class ParkServerDemo
{
	public static void main(String[] args)
	{
		BeanContext.startPark();
	}
}