package com.fourinone;
import java.rmi.Remote;
interface ParkActive extends ParkStatg,Remote{
}