package com.fourinone;
public interface CoolKeyResult{
	public CoolHashMap.CoolKeySet nextBatchKey(int batchLength);
}