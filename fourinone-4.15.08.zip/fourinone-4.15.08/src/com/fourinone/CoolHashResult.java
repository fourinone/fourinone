package com.fourinone;
public interface CoolHashResult{
	public CoolHashMap nextBatch(int batchLength);
}