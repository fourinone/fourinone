package com.fourinone;
public interface ObjectVersion{
	public Long getVid();
}