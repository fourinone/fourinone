package com.fourinone;
import java.io.Serializable;
interface ParkStatg extends Serializable{
	static final long serialVersionUID = 2983113349866492266L;
}