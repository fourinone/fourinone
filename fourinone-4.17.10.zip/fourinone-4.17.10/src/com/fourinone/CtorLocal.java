package com.fourinone;

public interface CtorLocal
{
	public WareHouse giveTask(WareHouse inhouse);
}