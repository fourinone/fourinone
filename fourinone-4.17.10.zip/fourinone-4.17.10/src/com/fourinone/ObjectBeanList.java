package com.fourinone;

import java.util.ArrayList;
import java.util.List;

class ObjectBeanList<E> extends ArrayList implements List{
	Long vid;
}