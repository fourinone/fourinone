package com.fourinone;

public interface WorkerProxy
{
	public void setWorker(MigrantWorker mw);
}