package com.fourinone;

public enum DelegatePolicy{
	Begin,Implements,End 
}